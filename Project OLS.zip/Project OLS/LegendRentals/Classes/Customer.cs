﻿//TRI

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LegendRentals
{
    public class Customer
    {
        public string CustomerID { get; private set; }
        public string PassWord { get; private set; }
        public string customerFirstname { get; private set; }
        public string customerLastname { get; private set; }

        public Customer(string CustomerID, string PassWord, string customerFirstname, string customerLastname)
        {
            this.CustomerID = CustomerID;
            this.PassWord = PassWord;
            this.customerFirstname = customerFirstname;
            this.customerLastname = customerLastname;
        }
    }
}