export class Phone{
    id: string;
    name: string;
    desc: string;
    price: number;
    updated: string;
}