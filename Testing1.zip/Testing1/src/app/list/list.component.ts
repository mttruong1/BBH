import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Phone } from './phone';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent implements OnInit {
  phoneList: Phone[];
  phoneInput: Phone;
  
  constructor(private apiService: ApiService) {
    this.phoneInput = new Phone();
   }
  
  ngOnInit() {
    
  }

  getphoneList(){
    this.apiService.getPhoneList()
      .subscribe(phoneList => {
        this.phoneList = phoneList;
        console.log(phoneList);
      })
  }

  addphoneList(){
    this.apiService.addPhoneList(this.phoneInput)
      .subscribe(phone => {
        this.phoneList.push(phone)});

    }

  // submitForm() {
  //   this.apiService.addPhoneList(this.phoneInput).subscribe(response => {
  //     console.log(response)
  //   });
  // }
}
