import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Phone } from './list/phone';
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }
  phoneUrl = './assets/data.json'

  getPhoneList(): Observable<Phone[]>{
    return this.http
      .get<Phone[]>(this.phoneUrl)
  }

  addPhoneList(phoneInput: Phone): Observable<Phone>{
    return this.http
      .post<Phone>(this.phoneUrl, phoneInput);
  }
}
